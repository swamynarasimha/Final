﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;//adding namespaces 
using SalesMan_Entites;
using SalesMan_Exception;
using SalesMan_DAL;
/*Emp id:172304
    AuthorName:P.L.S.Supriya
    File:bal
    CreationDate:12-02-2019*/

namespace SalesManBusinessAccessLayer
{
    // Creating SalesMan BusinessAccessLayer
    public class SalesMan_Bal
    {
        //Validating SalesMandata

     private static bool ValidateSalesMan(SalesMan Salesman)

        {
            //creating  string builder instance
             StringBuilder sb = new StringBuilder();

               bool validSalesman = true;

            if (Salesman.SalesmanCode == string.Empty)

            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Salesman Code cannot be empty");
            }

            if (Salesman.SalesmanCode.Length != 4)

            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Excatly required 4 Digit salesman code");
              
            }

       if (Salesman.Region.Equals("North") || Salesman.Region.Equals("West") || Salesman.Region.Equals("East") || Salesman.Region.Equals("South"))

            {
            }

            else
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Region has to be North , West , East or South");
            }

            if (validSalesman == false)
            {

                throw new SalesMan_Exception.SalesManException(sb.ToString());
            }
            return validSalesman;
   }

        public static SalesMan SearchSalesmanBL(string searchSalesmanCode)

        {
            SalesMan SearchSalesman = null;

            try {
                SalesMan_DAL.SalesManDal SalesmanDAL = new SalesMan_DAL.SalesManDal();
                SearchSalesman = SalesmanDAL.SearchSalesmanDAL(searchSalesmanCode);
            }
            catch (SalesMan_Exception.SalesManException ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;

            }
           return SearchSalesman;

        }
        public static bool SerializeDataBL(SalesMan Salesman)

        {
            bool SalesmanSerialized = false;

            try
            {

                if (ValidateSalesMan(Salesman))

                {
                    SalesMan_DAL.SalesManDal SalesmanDAL = new SalesMan_DAL.SalesManDal();

                    SalesmanSerialized = SalesmanDAL.SerializeDataDAL(Salesman);

                }

            }
            catch (SalesMan_Exception.SalesManException e)

            {

                throw e;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return SalesmanSerialized;
        }
            public static List<SalesMan> DeserializeDataBL()

             {

               List<SalesMan> SalesmanList = null;

                try

                  {

                    SalesMan_DAL.SalesManDal SalesmanDAL = new SalesMan_DAL.SalesManDal();

                    SalesmanList = SalesmanDAL.DeserializeDataDAL();
            }
                 
            catch (SalesMan_Exception.SalesManException e)

              {

                  throw e;
            }

            catch (Exception ex)
            {

                throw ex;

            }

            return SalesmanList;

        }

    }

}



    
