﻿
namespace clslib_Calculator
{
    public class Calculator
    {
        public int Add(int n1, int n2)
        {
            return n1 + n2;
        }
    }
}
