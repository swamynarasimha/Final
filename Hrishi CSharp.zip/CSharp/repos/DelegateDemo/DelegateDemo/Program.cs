﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DelegateDemo
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Calc calc = new Calc();
//            ////Step 2: Creating Instance of Delegate
//            //CalcDelegate calcDelegate = new CalcDelegate(calc.Add);
//            //calcDelegate += new CalcDelegate(calc.Sub);
//            //calcDelegate += new CalcDelegate(calc.Mult);

//            //CalcDelegate del1 = new CalcDelegate(calc.Add);   //normal delegate
//            //CalcDelegate del1 = delegate (int n1, int n2) { Console.WriteLine(n1 + n2); };     //Anonymous Delegate

//            CalcDelegate del1 = (n1, n2) => Console.WriteLine(n1 + n2);     //Lambda Expression 
//            CalcDelegate del2 = new CalcDelegate(calc.Sub);
//            CalcDelegate del3 = new CalcDelegate(calc.Mult);
//            CalcDelegate del4 = new CalcDelegate(calc.Div);
//            CalcDelegate de1 = (CalcDelegate)Delegate.Combine(del1, del2, del3, del4);
//            //de1(3, 2);

//            CalcDelegate d1 = (CalcDelegate)Delegate.Remove(del1, del2);
//            d1(3, 2);
//            //Step 3: Invoking Delegate
//            //calcDelegate(2, 3);


//            Console.ReadKey();
//        }
//    }
//}
