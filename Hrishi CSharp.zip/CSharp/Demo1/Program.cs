using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using clslib_Calculator; //Step-2
namespace Demo1
{   
    class Program
    {   
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello students, module 2 exam is cancelled");
            Calculator calculator = new Calculator();
            Console.Write("Enter first number:");
            int n1 =int.Parse(Console.ReadLine());
            Console.Write("Enter second number:");
            int n2 = int.Parse(Console.ReadLine());
            int res = calculator.Add(n1, n2);
            Console.WriteLine("Result is: "  +res);

            Console.ReadKey();
        }
    }
}
