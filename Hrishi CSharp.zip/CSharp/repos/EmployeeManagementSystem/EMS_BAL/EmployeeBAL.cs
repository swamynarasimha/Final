﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_DAL;
using EMS_Entities;
using EMS_Exceptions;
using System.Text.RegularExpressions;

namespace EMS_BAL
{
    public class EmployeeBAL
    {
        EmployeeDAL employeeDAL = new EmployeeDAL();

        public bool IsValid(Employee employee )
        {                                       
            bool valid = true;                         // string is immutable... appending wastes old memory instead of updating it
            StringBuilder sb = new StringBuilder();    //stringbuilder is collection of mutable objects

            if(employee.EmpId<101 || employee.EmpId > 99999)       //range 101-99999
            {
                sb.Append("Employee id should be in range 101-99999");
                valid = false;
            }

            if (Regex.IsMatch(employee.EmpName, "^[{L} .-]+$"))       //empname
            {
                sb.Append("Employee name should not contain special characters");
                valid = false;
            }

            //if (employee.EmpId < 101 || employee.EmpId > 99999)       //salary
            //{
            //    sb.Append("Employee id should be in range 101-99999");
            //    valid = false;
            //}

            if (employee.DOJ > DateTime.Now)       //Date of joining  before todays date
            {
                sb.Append("Employee date of joining should be always past date");
                valid = false;
            }

            if (!valid)
            {
                throw new EmployeeValidationException(sb.ToString());
            }
            return valid;
        }

        public void Add(Employee employee)             //Add new employee
        {
            try
            {
                if (IsValid(employee))
                {

                    employeeDAL.Insert(employee);
                }
            }
            catch(EmployeeValidationException ex1)
            {
                throw ex1;
            }

            catch(Exception ex2)
            {
                throw ex2;
            }
        }

        public void Modify(Employee employee)         //Modify Details
        {
            try
            {
                if (IsValid(employee))
                {

                    employeeDAL.Update(employee);
                }
            }
            catch (EmployeeValidationException ex1)
            {
                throw ex1;
            }

            catch (Exception ex2)
            {
                throw ex2;
            }
        }

        public void Remove(int empId)         //Modify Details
        {
            try
            {
                

                    employeeDAL.Delete(empId);
                
            }
            catch (EmployeeNotFoundException ex1)
            {
                throw ex1;
            }

            catch (Exception ex2)
            {
                throw ex2;
            }
        }

        public List<Employee> GetAll()
        {
            return employeeDAL.SelectAll();
        }

    }
}
