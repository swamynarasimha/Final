﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter rollno: ");
            int rollno = int.Parse(Console.ReadLine());
            Console.Write("Enter name: ");
            string name = (Console.ReadLine());
            Console.Write("Enter feesPaid: ");
            double fp = double.Parse(Console.ReadLine());
            Console.Write("Enter DOB: ");
            DateTime date = DateTime.Parse(Console.ReadLine());
            Console.Write("Enter Highest Qualification 1.UnderGraduate 2.Graduate 3.PostGraduate ");
            HighestQualification HighQ = (HighestQualification)int.Parse(Console.ReadLine());
            Student student = new Student(rollno,name,fp,date,HighQ);

            Console.WriteLine(student.GetStudentDetails());
            Console.ReadKey();
        }
    }
}
