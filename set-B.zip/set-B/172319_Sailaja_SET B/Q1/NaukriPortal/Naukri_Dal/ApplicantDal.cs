﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using NaukriEntity;
using NaukriException;
using System.Runtime.Serialization.Formatters.Binary;

namespace Naukri_Dal
{
    public class ApplicantDal
    {
        //using list collection to store the data from student

        public static List<Applicants> app = new List<Applicants>();
            
        public bool AddApplicantDAL(Applicants applicant)
        {
            //returns boolean value to know whether the applicant is added or not
            bool ApplicantAdded = false;
            try
            {
                app.Add(applicant);
                ApplicantAdded = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ApplicantAdded;

        }
        public Applicants SearchApplicantDAL(String Qualification)
        {

            try
            {
                Applicants searchApplicant = null;
                foreach (var applicant in app)
                {
                    if (applicant.Qualification == Qualification)
                    {
                        searchApplicant = applicant;
                    }

                }
                return searchApplicant;
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        public static void SerializeData()
        {
            FileStream stream;
            try
            {
                stream = new FileStream(@"ApplicantDetails.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, app);
                stream.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<Applicants> DeserializeData()
        {
            FileStream stream = new FileStream(@"ApplicantDetails.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            app = formatter.Deserialize(stream) as List<Applicants>;
            return app;
        }

    }
}
