﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ambedkar_Customer_Lab
{
    class Customer
    {
        string CustomerName;
        int CustomerID, Phone;
        string Address, EmailID;
        List<Customer> lst = new List<Customer>();
        public void AddCustomer()
        {
            Customer cr = new Customer();
            Console.WriteLine("Enter Customer name");
            cr.CustomerName = Console.ReadLine();

            Console.WriteLine("Enter Customer ID:");

            cr.CustomerID = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Phone Number");

            cr.Phone = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Address");

            cr.Address = Console.ReadLine();

            Console.WriteLine("Enter email address");

            cr.EmailID = Console.ReadLine();

            lst.Add(cr);

            Choice();

        }



        public void displaylist()

        {

            if (lst.Count == 0 || lst == null)

            {

                Console.WriteLine("No records");

            }

            else

            {

                foreach (var cus in lst)

                {

                    Console.WriteLine("Customer Name" + cus.CustomerName);

                    Console.WriteLine("Customer ID" + cus.CustomerID);

                    Console.WriteLine("Customer phone number" + cus.Phone);

                    Console.WriteLine("Address" + cus.Address);

                    Console.WriteLine("Email ID" + EmailID);

                }

            }

            Choice();

        }



        public void Choice()

        {

            string choice;

            do

            {

                Console.WriteLine("\n***********Customer Details***********");

                Console.WriteLine("1. Add Customer");

                Console.WriteLine("2. Get all Customer Details");

                Console.WriteLine("Enter your choice");

                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)

                {

                    case 1:

                        AddCustomer();

                        break;

                    case 2:

                        displaylist();

                        break;

                }

                Console.WriteLine("Do you want to contiue(y/n)?");

                choice = Console.ReadLine();

            }

            while ((choice == "y"));

            Console.Read();



        }

        public static void Main(string[] args)

        {

            Customer c = new Customer();

            c.Choice();

        }
    };
}
