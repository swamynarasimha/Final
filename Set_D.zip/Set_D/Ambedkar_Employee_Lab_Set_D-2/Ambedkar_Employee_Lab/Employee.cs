﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ambedkar_Employee_Lab
{
    class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public string Gender { get; set; }
        public string DateOfBirth { get; set; }
        public Employee() //Default Constructor
        {

        }
        // Prameterized Constructor
        public Employee(int EmpID, string EmpName, string Gender, string DateOfBirth) //Overloaded Constructor
        {
            this.EmpID = EmpID;
            this.EmpName = EmpName;
            this.Gender = Gender;
            this.DateOfBirth = DateOfBirth;
        }
        void displayDetails() //Method Display Details to display details.
        {
            WriteLine($"EmpID : {EmpID} \n Employee Name : {EmpName} \n Gender : { Gender} \n Date Of Birth : {DateOfBirth}");
   
        }
        static void Main(string[] args)
        {
            Employee e = new Employee(1,"Ambedkar","Male","01-01-1997");
            e.displayDetails();
            //Invoke method DisplayDetails.
            ReadKey();
        }
    };
}
