﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SalesMan_Entites;
using SalesMan_Exception;
using SalesManBusinessAccessLayer;
/*Emp id:172304
    AuthorName:P.L.S.Supriya
    File:presentation layer
    CreationDate:12-02-2019*/


namespace SalesManPresentationLayer
{
    class SalesManPL
    {

        static void Main(string[] args)
        {
            PrintMenu();
        }
        private static void PrintMenu()

        {
            string Select;
            do

            {
                Console.WriteLine($"******S@ur@bh Jewelers*******");

                Console.WriteLine($"Salesman Data Management System ");

                Console.WriteLine($"1. Searching performance details of particular SalesMan");

                Console.WriteLine("2. Serialize the data");

                Console.WriteLine("3. Deserialize the data");

                Console.WriteLine("Enter choice");

                int Choice = Convert.ToInt32(Console.ReadLine());
                switch (Choice)

                {

                    case 1:

                        SearchSalesmanCode();

                        break;

                    case 2:

                        SerializeData();

                        break;

                    case 3:

                        DeserializeData();

                        break;

                    default:

                        Console.WriteLine("invalid choice:select 1-3");

                        break;

                }

                Console.WriteLine("Do you want to contiue(y/n)?");

                Select = Console.ReadLine();

            } while ((Select == "y"));

            Console.Read();
        }
           private static void SearchSalesmanCode()
              {
               try
                {
                       string searchSalesmanCode;

                    Console.WriteLine("Enter Salesman Code to Search performance:");

                    searchSalesmanCode = Console.ReadLine();

                    SalesMan searchSalesman = SalesManBusinessAccessLayer.SalesMan_Bal.SearchSalesmanBL(searchSalesmanCode);
                    if (searchSalesman != null)

                    {
                        Console.WriteLine("-------****---------");
                        Console.WriteLine($"Salesman Code,Name,Region,target,actual sales");

                        Console.WriteLine("-------****---------");

                        Console.WriteLine("{0},{1},{2},{3},{4}", searchSalesman.SalesmanCode, searchSalesman.SalesmanName, searchSalesman.Region, searchSalesman.TargetSet, searchSalesman.ActualSales);

                        Console.WriteLine("-------****---------");

                    }

                    else

                    {

                        Console.WriteLine(" Salesman Details Not Available");

                    }

                }

                catch (SalesMan_Exception.SalesManException ex)

                {

                    Console.WriteLine(ex.Message);
                }
            }
            //Perform serialization on the data

            private static void SerializeData()

            {
                try

                {

                    SalesMan NewSalesman = new SalesMan();

                    Console.WriteLine("Enter Salesman Code :");

                    NewSalesman.SalesmanCode = Console.ReadLine();

                    Console.WriteLine("Enter Salesman Name :");

                    NewSalesman.SalesmanName = Console.ReadLine();

                    Console.WriteLine("Enter Region (North,West,East,South) :");

                    NewSalesman.Region = Console.ReadLine();

                    Console.WriteLine("Enter Target set :");

                    NewSalesman.TargetSet = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter Actual sale :");

                    NewSalesman.ActualSales = Convert.ToInt32(Console.ReadLine());

                    bool SalesmanSerialized = SalesManBusinessAccessLayer.SalesMan_Bal.SerializeDataBL(NewSalesman);

                    if (SalesmanSerialized)

                        Console.WriteLine("Salesmandata is Serialized");

                    else

                        Console.WriteLine("Salesmandata is  not Serialized");

                }

                catch (SalesMan_Exception.SalesManException ex)

                {

                    Console.WriteLine(ex.Message);

                }

            }
            //Perform Deserialization on the data

            private static void DeserializeData()

            {

                try

                {

                    List<SalesMan> SalesManList = SalesManBusinessAccessLayer.SalesMan_Bal.DeserializeDataBL();

                    if (SalesManList != null && SalesManList.Count > 0)

                    {

                        Console.WriteLine("-------****---------");
                        Console.WriteLine("Salesman Code ,Name,Region");

                        Console.WriteLine("-------****---------");

                        foreach (SalesMan Salesman in SalesManList)

                        {

                            Console.WriteLine($"{0},{1},{2},{3},{4}", Salesman.SalesmanCode, Salesman.SalesmanName, Salesman.Region, Salesman.TargetSet, Salesman.ActualSales);

                        }
                        Console.WriteLine("-------****---------");

                    }

                    else

                    {

                        Console.WriteLine(" Serialized Data Not Available");

                    }

                }

                catch (SalesMan_Exception.SalesManException ex)

                {

                    Console.WriteLine(ex.Message);

                }

            }

        }

    }


    

