﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DelegateDemo
//{
//    class BankAccountTest
//    {
//        static void Main(string[] args)
//        {
//            BankAccount bankAccount = new BankAccount(101, 10000);
            
//            //NotificationDelegate notifiDel = new NotificationDelegate(Notifications.SendSMS);   //Step 2: Instantiation Delegate
//            //notifiDel += new NotificationDelegate(Notifications.SendMail);

//            //Step 2 Registering an event or subscribing an event
//            bankAccount.BalanceChanged += new NotificationDelegate(Notifications.SendSMS);
//            bankAccount.BalanceChanged += new NotificationDelegate(Notifications.SendMail);

//            bankAccount.With(1000);
//            //bankAccount.Depo(200);

//            Console.ReadKey();
//        }


//    }
//}
