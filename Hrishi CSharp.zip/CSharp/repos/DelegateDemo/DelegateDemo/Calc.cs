﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    //STEP:1 Defining Delegate
    public delegate void CalcDelegate(int n1, int n2);
    public class Calc
    {
        //public void Add(int n1, int n2)
        //{
        //    Console.WriteLine(n1 + n2);
        //}
        public void Sub(int n1, int n2)
        {
            Console.WriteLine(n1 - n2);
        }
        public void Mult(int n1, int n2)
        {
            Console.WriteLine(n1 * n2);
        }
        public void Div(int n1, int n2)
        {
            Console.WriteLine( n1 / n2);
        }
    }
}
