﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Emp id:172304
    AuthorName:P.L.S.Supriya
    File:entities
    CreationDate:12-02-2019*/

namespace SalesMan_Entites
{[Serializable]
    public class SalesMan
    {
        public String SalesmanCode{ get; set; }
        public String SalesmanName { get; set; }
        public String Region{ get; set; }
        public int TargetSet { get; set; }
        public int ActualSales { get; set; }
    }
}
