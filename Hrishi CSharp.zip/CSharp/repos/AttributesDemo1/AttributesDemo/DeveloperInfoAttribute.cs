﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AttributesDemo
{
    [AttributeUsage(AttributeTargets.All,AllowMultiple = true)]
    class DeveloperInfoAttribute :Attribute
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string DeveloperName { get; set; }
        public string ProjectName { get; set; }
    }
}
