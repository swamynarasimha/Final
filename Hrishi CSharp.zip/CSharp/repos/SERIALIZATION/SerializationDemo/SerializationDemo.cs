﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerializationDemo
{
    class Employee
    {
        static void Main(string[] args)
        {
            List<Employee> c_emp = new List<Employee>
            {
                new Employee{ empID=101 , empName="Pranali",Salary=500000},
                new Employee{ empID=101 , empName="Pranali",Salary=500000},
                new Employee{ empID=101 , empName="Pranali",Salary=500000}
            };
        }
    }
}
