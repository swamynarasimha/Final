﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
    abstract class Employee
    {
        protected int empid;
        protected string empName;
        protected double salary, gs, ns, pf;


        public Employee()
        {

        }

        public Employee(int empid, string empName, int salary)
        {
            this.empid = empid;
            this.empName = empName;
            this.salary = salary;

        }

        public abstract void CalcSalary();         // Virtual is used to override method
        //{
        //    pf = salary * 0.12;
        //    gs = salary + pf;
        //    ns = gs + pf;
        //}

        public string GetDetails()
        {
            return " EmployeeID: " + empid + " Name " + empName + " GS: " + gs + " NS: " + ns;
        }
    }

    class Manager : Employee
    {
        double incentive;
        public Manager(int empid, string empName, int salary)
            : base(empid, empName, salary)                              //base keyword used to get attributes from base class
        {
            incentive = 5000;
        }

        public override void CalcSalary()
        {
            // base.CalcSalary();
            gs = gs + incentive;
            ns = gs + pf;

        }

        class HRManager : Manager
        {
            public sealed override void CalcSalary()    //sealed does not allow to override onwards
            {
                base.CalcSalary();
            }
        }
        class ABCHRManager : Manager
        {


        }
    }
}
