﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    [DeveloperInfo(ProjectName = "Abc", EmpId= 123, DeveloperName = " Hrishi")]

    [DeveloperInfo(ProjectName = "Abc", EmpId = 123, DeveloperName = " Mukund")]

    class Sample { }
    class Program
    {
        static void Main(string[] args)
        {
            Attribute[] attrs =Attribute.GetCustomAttributes(typeof(Sample));
            foreach (DeveloperInfoAttribute da in attrs)
            {
                Console.WriteLine($"EmpId:{ da.EmpId},EmpName:{ da.EmpName},ProjName:{ da.ProjectName},DeveloperName:{ da.DeveloperName}");
            }
            Console.ReadKey();
        }
    }
}
