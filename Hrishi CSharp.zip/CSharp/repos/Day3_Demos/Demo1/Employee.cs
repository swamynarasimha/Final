﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1 //inheritance
{
    abstract class Employee                       //function is abstract so its compulsory to marks the class also as abstract
    {
        protected int empid;
        protected string empname;
        protected double salary,gs,ns,pf;

        public Employee(int empid, string empname, int salary)
        {
            this.empid = empid;
            this.empname = empname;
            this.salary = salary;

        }

       // public abstract double NS { set; }   example of abstract property 

        public abstract /*virtual*/ void CalcSalary();          //virtual  keyword helps to override the method
        //{
        //    pf = (salary * 0.12);
        //    gs = salary + pf;
        //    ns = gs - pf;


        //}

        public string GetDetails()
        {
            return " Empid: " +empid+ " Name: " +empname+ " GS: " + gs + " NS: " + ns;
        }
       
    }

    class Manager : Employee
    {
        double incentives;
        public Manager(int empid, string empname, int salary)
            : base(empid,empname,salary)            //base keyword to access parameters from base class
        {
            incentives = 5000;
        }

        public override void CalcSalary()   //override keyword to override virtual or abstract method
        {
            //base.CalcSalary();
            pf = (salary * 0.12);
            gs = gs + incentives;
            ns = gs + pf;          //field changes so write again or it will show above value
        }


    }

    class HRManager : Manager
    {

        public sealed override void CalcSalary()    //sealed does not allow overriding hence onwards
        {
            base.CalcSalary();
        }
    }

    class ABCHRManager  : Manager
    {


    }
}
