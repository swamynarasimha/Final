﻿using SMS_DAL;
using SMS_Entities;
using SMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*Emp Id:172322
 * Author Name: Susmitha
 * Creation Date:12/02/2019
*/
namespace SMS_BAL
{
    public class StudentBAL
    {
        //using generic concept
        public static List<Student> stud = new List<Student>();
        // private static object studs;
        private static bool ValidateStudent(Student student)
        {
            StringBuilder sb = new StringBuilder();
            bool validStudent = true;
            //validating whether the data is empty or not
            if (student.StudentId <= 6)
            {
                validStudent = false;
                sb.Append(Environment.NewLine + "Invalid Student RollNo");

            }
            if (student.StudentName == string.Empty)
            {
                validStudent = false;
                sb.Append(Environment.NewLine + "Student Name Required");

            }
            if (student.CourseName==string.Empty)
            {
                validStudent = false;
                sb.Append(Environment.NewLine + "Invalid Course Name");
            }
            //if (student.Grade!= 4)

            //{

            //    validStudent = false;

            //    sb.Append(Environment.NewLine + "Required 4 Digit Grade code");

            //}
            
            if (student.Grade.Equals('A') || student.Grade.Equals('B')|| student.Grade.Equals('C')|| student.Grade.Equals('F'))
            { }

            else

            {

                validStudent = false;

                sb.Append(Environment.NewLine + "Grade Must be A,B,C,F");

            }
            if (validStudent == false)
                throw new StudentNotFoundException(sb.ToString());
            return validStudent;
        }
        //Adding student information
        public static bool AddStudentBAL(Student newstudent)
        {
            bool StudentAdded = false;
            try
            {
                if (ValidateStudent(newstudent))
                {
                    StudentDAL studentDAL = new StudentDAL();
                    StudentAdded = studentDAL.AddStudentDAL(newstudent);
                }
            }
            catch (StudentNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StudentAdded;
        }
        //displaying student
        public static Student DisplayParticularStudentBAL(int displayStudentID)
        {
            Student displayStudent = null;
            try
            {
                StudentDAL studentDAL = new StudentDAL();
                displayStudent = studentDAL.DisplayParticularStudentDAL(displayStudentID);
            }
            catch (StudentNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return displayStudent;

        }
        public static void SerializeData()
        {
            StudentDAL.SerializeData();
        }
    }
}
