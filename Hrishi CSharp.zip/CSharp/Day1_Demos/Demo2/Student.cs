﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Demo2
{
    public enum HighestQualification{ undergrad=1, Grad , PostGrad }
    //enum,class,struct,delegate,interface == type
   public class Student
    {

        int rollno;
        string name;
        double feesPaid;
        DateTime dob;
        HighestQualification HQ;
        //UnderGraduate,Gradyate,PostGraduate
        public Student(int rollno, string name, double feesPaid, DateTime dob ,HighestQualification HQ)
        {
            this.rollno = rollno;
            this.name = name;
            this.feesPaid = feesPaid;
            this.dob = dob;
            this.HQ = HQ;
        }
        public string GetStudentDetails()
        {
            return "Rollno:" +rollno+  ",Name:" +name+"Feespaid:" +feesPaid+"Dob:" +dob+ "HighestQual: " +HQ;

        }


    }
}
