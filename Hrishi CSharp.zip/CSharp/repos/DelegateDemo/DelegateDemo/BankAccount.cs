﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    class BankAccount
    {
        public int AccNo { get; set; }
        public double Balance { get; set; }
        public event NotificationDelegate BalanceChanged; // step 1 declaring event

        public BankAccount(int accNo, double balance)
        {
            this.AccNo = accNo;
            this.Balance = balance;
            //this.notification = notification;
        }


        public void With(double amount)
        {
            if(Balance >= amount)
            {
                double oldBal = Balance;
                Balance -= amount;
                BalanceChanged($"Balance changed from {oldBal} to {Balance}");   //Step 3 : raising an event
            }

        }
        public void Depo(double amount)
        {
            double oldBal = Balance;
            Balance += amount;
            BalanceChanged($"Balance changed from {oldBal} to {Balance}");     //Step 3 Raising an event
        }
    }
}
