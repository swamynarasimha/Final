﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NaukriEntity;
using NaukriException;
using Naukri_Dal;

namespace Naukri_Bal
{
    public class ApplicantBal
    {
        public static List<Applicants> appl = new List<Applicants>();
        public static object studs;
        private static bool ValidateApplicant(Applicants applicant)
        {
            StringBuilder sb = new StringBuilder();
            bool validApplicant = true;

            // checking whether qualification entered is BE, ME, MCA

            if ((applicant.Qualification != "BE") && (applicant.Qualification != "ME") && (applicant.Qualification != "MCA"))
            {
                validApplicant = false;
                sb.Append(Environment.NewLine + "Qualification has to be BE, ME , MCA and should be in same format as capitals");

            }

            // checking whether the entered city is mumbai , pune, chennai, banglore

            if ((applicant.City != "Mumbai") && (applicant.City != "Pune") && (applicant.City != "Chennai") && (applicant.City != "Banglore"))
            {
                validApplicant = false;
                sb.Append(Environment.NewLine + "city should be Mumbai, Pune, Chennai, Banglore and in same format");
            }

            // Checking whether the entered phone number is 10 digits or not

            if (applicant.MobileNo.Length != 10)
            {
                validApplicant = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (validApplicant == false)
                throw new ApplicantNotFoundException(sb.ToString());
            return validApplicant;
        }

        //Method To Add Student

        public static bool AddApplicantBAL(Applicants newApplicant)
        {
            bool ApplicantAdded = false;
            try
            {
                if (ValidateApplicant(newApplicant))
                {
                    ApplicantDal applicantDAL = new ApplicantDal();
                    ApplicantAdded = applicantDAL.AddApplicantDAL(newApplicant);
                }
            }
            catch (ApplicantNotFoundException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ApplicantAdded;
        }
        public static void SerializeData()
        {
            ApplicantDal.SerializeData();
        }
        public static void DeserializeData()
        {
            ApplicantDal.DeserializeData();
        }

        // Searching the data from applicants on the basis of Qualification

        public static Applicants SearchApplicantBAL(string searchStudentQualification)
        {
            Applicants searchStudent = null;
            try
            {
                ApplicantDal studentDAL = new ApplicantDal();
                searchStudent = studentDAL.SearchApplicantDAL(searchStudentQualification);
            }
            catch (ApplicantNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchStudent;

        }
    }
}
