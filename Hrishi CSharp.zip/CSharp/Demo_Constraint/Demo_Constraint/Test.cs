﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections

namespace Demo_Constraint
{
    class Test :IEnumerable
    {
        // 13 -> 1,2,3,4,5,6,7,8,9,10,11,12,13
        static IEnumerator MyMethod(int input)
        {
            //int[] nos = new int[input];
            for(int i=1; i<=input; i++)
            {
                //nos[i - 1] = i;
                yeild return i;
            }
            //return nos;

        }
        static void Main(string[] args)
        {
            int input = 13;
            //int[] nos = MyMethod(input);
            foreach(var item in MyMethod(input))
            {
                //Console.WriteLine(item);

            }

        }
    }
}
