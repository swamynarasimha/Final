﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_Exceptions;
using EMS_BAL;

namespace EmployeeManagementSystem
{
    class Program
    {
        private static void Menu()
        {
            Console.WriteLine("\n***********Menu***********");
            Console.WriteLine("1. Add New Employee");
            Console.WriteLine("2. Update Employee");
            Console.WriteLine("3. Delete Employee");
            Console.WriteLine("4. Display All Employees");
            Console.WriteLine("5. Exit");

            Console.WriteLine("****************************\n");
        }
        static void Main(string[] args)
        {

            int choice;
            do
            {
                
                EmployeeBAL employeeBAL = new EmployeeBAL();
                Employee employee = new Employee
                Menu();
                Console.WriteLine("Enter your choice: ");
                choice = Convert.ToInt16(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        employeeBAL.Add(employee);
                        break;
                    case 2:
                        employeeBAL.Modify(employee);
                        break;
                    case 3:
                        employeeBAL.Remove(employee.EmpId);
                        break;
                    case 4:
                        employeeBAL.GetAll(employee);
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("INvalid Choice");
                }

            } while (choice != -1);
        }

            try
            {


            }
            catch (EmployeeValidationException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (EmployeeNotFoundException ex2)
            {
                Console.WriteLine(ex2.Message);
            }
            catch (Exception ex3)
            {
                throw ex3;
            }
            Console.ReadKey();
        }
    }
}


    
//                static void DisplayEmployees(List<Employee> employee)
//{

//}
//static void Main(string[] args)
//{
//    try
//    {
//        /////////////////////////////////////////////////////
//        EmployeeBAL employeeBAL = new EmployeeBAL();
//        Employee employee = new Employee
//        {
//            EmpId = 1022,
//            DOJ = DateTime.Now.AddDays(-2),
//            Salary = 120000,
//            EmpName = "Rohan"
//        };
//        employeeBAL.Add(employee);
//        Console.WriteLine("Inserted ");

//        DisplayEmployees(employeeBAL.GetAll());
        
//        List<Employee> employees = employeeBAL.GetAll();
//        foreach (var item in employees)
//        {
//            Console.WriteLine(item);    //EMS>Entities.Employee
//        }


//        ///////////////////////////////////////////////////////////////////


//        employee.DOJ = DateTime.Now.AddDays(-2);
//        employee.Salary = 120000;
//        employee.EmpName = "Swammy";

//        employeeBAL.Modify(employee);
//        Console.WriteLine("Updated ");

//        foreach (var item in employees)
//        {
//            Console.WriteLine(item);    //EMS>Entities.Employee
//        }

//        employeeBAL.Remove(1022);
//        Console.WriteLine("Deleted ");







//    }
//    catch (EmployeeValidationException ex1)
//    {
//        Console.WriteLine(ex1.Message);
//    }
//    catch (EmployeeNotFoundException ex2)
//    {
//        Console.WriteLine(ex2.Message);
//    }
//    catch (Exception ex3)
//    {
//        throw ex3;
//    }
//    Console.ReadKey();
//}
//    }
//}
