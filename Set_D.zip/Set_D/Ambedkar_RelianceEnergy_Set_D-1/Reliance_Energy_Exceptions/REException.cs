﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reliance_Energy_Exceptions
{
    public class REException : ApplicationException
    {
        public REException() : base() { }

        public REException(string message) : base(message) { }

        public REException(string message, Exception innerException) : base(message, innerException) { }
    }
}
