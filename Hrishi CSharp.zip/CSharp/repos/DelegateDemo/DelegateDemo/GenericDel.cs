﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DelegateDemo
//{
//    //delegate int AddDel1(int n1, int n2);
//    //delegate int AddDel2(int n1, int n2);
//    delegate RT AddDel1<RT, PT>(PT n1, PT n2);
//    class GenericDel
//    {


//        static int Add(int n1, int n2)
//        {
//            return n1 + n2;
//        }
//        //static short Add(int n1, int n2)
//        //{
//        //    return n1 + n2;
//        //}
//        static double Add(double n1, double n2)
//        {
//            return n1 + n2;
//        }
//        static void Main(string[] args)
//        {
//            // AddDel1 d1 = new AddDel1(Add);
//            //Console.WriteLine(d1(2, 4));
//            //AddDel2 d2 = new AddDel2(Add);


//            AddDel1<double, double> d1 = new AddDel1<double, double>(Add);
//            Console.WriteLine(d1(2.2, 4.4));
//            Console.ReadKey();
//        }
//    }
//}
