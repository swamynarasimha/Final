﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Emp id:172304
    AuthorName:P.L.S.Supriya
    File:exception
    CreationDate:12-02-2019*/

namespace SalesMan_Exception
{

    [Serializable]
    public class SalesManException : Exception
    {
        public SalesManException() { }
        public SalesManException(string message) : base(message) { }
        public SalesManException(string message, Exception inner) : base(message, inner) { }
        protected SalesManException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
