﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Reliance_Energy_Entities;
using Reliance_Energy_Exceptions;
using Reliance_Energy_Bill_DAL;
using System.Text.RegularExpressions;

namespace Reliance_Energy_Bill_BAL
{
    public class ElectricityBLL
    {
        private static bool ValidateElectricity(Electricity Electricity)
        {
            StringBuilder sb = new StringBuilder();
            bool validElectricity = true;
            if (Electricity.CustomerID <= 0)
            {
                validElectricity = false;
                sb.Append(Environment.NewLine + "Invalid Customer ID");
            }
            if (Electricity.BillNo <= 0)
            {
                validElectricity = false;
                sb.Append(Environment.NewLine + "Invalid Bill number");
            }
            if (Electricity.CustomerName == string.Empty)
            {
                validElectricity = false;
                sb.Append(Environment.NewLine + "Customer Name Required");
            }
            if (Electricity.Phone.Length <= 9 || Electricity.Phone.Length >= 11)
            {
                validElectricity = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (!Regex.IsMatch(Electricity.EmailID, @"^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$"))
            {
                sb.Append("Enter valid Email ID ..." + Environment.NewLine);
                validElectricity = false;
            }
            if(Electricity.UnitConsumed <= 0)
            {
                validElectricity = false;
                sb.Append("Enter Consumed units above 1..");
            }
            if (validElectricity == false)
                throw new REException(sb.ToString());
            return validElectricity;
        }
        public static bool AddElectricityBL(Electricity newElectricity)
        {
            bool ElectricityAdded = false;
            try
            {
                if (ValidateElectricity(newElectricity))
                {
                    ElectricityDAL ElectricityDAL = new ElectricityDAL();
                    ElectricityAdded = ElectricityDAL.AddElectricityDAL(newElectricity);
                }
            }
            catch (REException e)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ElectricityAdded;
        }
        public static List<Electricity> GetAllElectricitysBL()
        {
            List<Electricity> ElectricityList = null;
            try
            {
                ElectricityDAL ElectricityDAL = new ElectricityDAL();
                ElectricityList = ElectricityDAL.GetAllElectricitysDAL();
            }
            catch (REException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ElectricityList;
        }
        public static bool DeleteElectricityBL(int deleteElectricityID)
        {
            bool ElectricityDeleted = false;
            try
            {
                if (deleteElectricityID > 0)
                {
                    ElectricityDAL ElectricityDAL = new ElectricityDAL();
                    ElectricityDeleted = ElectricityDAL.DeleteElectricityDAL(deleteElectricityID);
                }
                else
                {
                    throw new REException("Invalid Electricity ID");
                }
            }
            catch (REException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ElectricityDeleted;
        }
        public static Electricity SearchElectricityBL(int searchElectricityID)
        {
            Electricity searchElectricity = null;
            try
            {
                ElectricityDAL ElectricityDAL = new ElectricityDAL();
                searchElectricity = ElectricityDAL.SearchElectricityDAL(searchElectricityID);
            }
            catch (REException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchElectricity;
        }
        public static bool UpdateElectricityBL(Electricity updateElectricity)
        {
            bool ElectricityUpdated = false;
            try
            {
                if (ValidateElectricity(updateElectricity))
                {
                    ElectricityDAL ElectricityDAL = new ElectricityDAL();
                    ElectricityUpdated = ElectricityDAL.UpdateElectricityDAL(updateElectricity);
                }
            }
            catch (REException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ElectricityUpdated;
        }
    };
}
