﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SalesMan_Entites;
using SalesMan_Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
/*Emp id:172304
    AuthorName:P.L.S.Supriya
    File:dal
    CreationDate:12-02-2019*/
namespace SalesMan_DAL
{
    public class SalesManDal
    {
        //Creating list to store the salesman report
     static   List<SalesMan> SMlist = new List<SalesMan>();
        //creting method to search the salesman in list
        public SalesMan SearchSalesmanDAL(string searchSalesmanCode)

        {

            SalesMan searchSalesman = null;

            try

            {
                //checking condition
                for (int i = 0; i < SMlist.Count; i++)

                {

                    SalesMan Salesman = SMlist[i];

                    if (Salesman.SalesmanCode == searchSalesmanCode)
                    {
                        searchSalesman = SMlist[i];
                        break;
                    }
                }
            }

            catch (Exception ex)

            {

                throw new SalesManException(ex.Message);

            }

            return searchSalesman;
        }
        // Code for Serializing salesman data
        public bool SerializeDataDAL(SalesMan newSalesman)
                {
            bool SalesManSerialized = false;
            try
            {
                SMlist.Add(newSalesman);

                SalesManSerialized = true;
                //creating filestream to create file and store the salesman details

               FileStream    fs = new FileStream("SalesDetails.txt", FileMode.Create,FileAccess.Write);
                //creating binaryFormatter to serialized the data
                BinaryFormatter Formatter = new BinaryFormatter();
                //calling serialize method to store the object data in binaryformat
               Formatter.Serialize(fs, SMlist);
//close the file stream close
                fs.Close();
            }

            catch (Exception ex)
               {

                throw new SalesMan_Exception.SalesManException(ex.Message);
               }
                return SalesManSerialized;

        }
        // Code for deserialize data

        public List<SalesMan> DeserializeDataDAL()
        {
            //Creating instance for filestream to open the file
          FileStream fs = new FileStream("SalesDetails.txt", FileMode.Open,FileAccess.Read);
            //creating binaryFormatter instance to deserialized the data
            BinaryFormatter formatter = new BinaryFormatter();
            //storing the deserialize data in list
            List<SalesMan> SalesManList = formatter.Deserialize(fs) as List<SalesMan>;
            //close the filestream
            fs.Close();

            return SalesManList;
        }
    }
}






    

