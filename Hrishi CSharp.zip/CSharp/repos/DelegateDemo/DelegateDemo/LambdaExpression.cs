﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    class LambdaExpression
    {
        static void Main(string[] args)
        {
            //Func<int, int, int> func1 = delegate (int n1, int n2)     //Anonymous
            //  {
            //      return n1 + n2;
            //  };

            //Func<int, int, int> func1 = (n1, n2) => n1 + n2;          //Lambda


            Func<int, int, int> func1 =  ( n1,  n2) => { int n3 = n1 + n2; Console.WriteLine(Hello); Console.WriteLine(n3); };    //Anonymous

            Console.WriteLine(func1(2,5));
            Console.ReadKey();
         }
    }
}
