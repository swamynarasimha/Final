﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    delegate void NotificationDelegate(string message);       //Step 1: DEfine Delegate
    class Notifications
    {
        public static void SendSMS(string message)
        {
            //Code to  send SMS
            Console.WriteLine("SMS: " + message);
        }
        public static void SendMail(string message)
        {
            //Code to  send Mail
            Console.WriteLine("Mail: " + message);
        }
        public static void SendVoiceCall(string message)
        {
            //Code to  send VoiceCall
            Console.WriteLine("Voice: " + message);
        }
    }
}