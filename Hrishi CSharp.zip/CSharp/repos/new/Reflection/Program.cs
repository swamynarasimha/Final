﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {

            string path = @"C:\Users\hkamble\source\repos\EmployeeManagementSystem\EMS_DAL\bin\Debug\EMS_DAL.dll";
            Assembly assembly = Assembly.LoadFrom(path);   //
            Type[] types = assembly.GetTypes();


            //Console.WriteLine("Properties" + types.fullname);
            foreach (Type t in types)
            {
                //Console.WriteLine("Properties" + t.fullname);
                Console.WriteLine(t.Name);    //MyCalc | Employee
            }
            //foreach (PropertyInfo pt in t.GetProperties())
            //{

            //    Console.WriteLine(pt.Name);    //MyCalc | Employee
            //}
            Console.ReadKey();
        }
    }
}
