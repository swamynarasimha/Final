﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reflection
{
    class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }

        public Employee() { }

        public Employee(int empId, string empName)
        {
            this.EmpId = empId;
            this.EmpName = empName;

        }

        public string GetDetails()
        {
            return $"{EmpId}, {EmpName}";
        }
    }
}
